<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['login']) || !$_SESSION['login']) {
    header('Location: index.php');
    exit;
}

// Importar la conexión a la base de datos
require 'includes/config/database.php';
$db = conectarDB();

// Consultar los vendedores
$query = "SELECT * FROM vendedores";
$resultadoConsulta = mysqli_query($db, $query);

// Manejar mensajes de resultado
$resultado = $_GET['resultado'] ?? null;

// Procesar solicitud POST para eliminar un vendedor
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);

    if ($id) {
        // Eliminar vendedor de la base de datos
        $query = "DELETE FROM vendedores WHERE id = ${id}";
        $resultado = mysqli_query($db, $query);

        if ($resultado) {
            header('Location: vendedor.php?resultado=3');
            exit;
        } else {
            echo "Error al eliminar el vendedor.";
        }
    } else {
        echo "ID no válido.";
    }
}

// Incluir la plantilla del encabezado
require 'includes/funciones.php';
incluirTemplate('header');
?>

<main class="contenedor seccion">
    <h1>Administrador de Vendedor(a)</h1>

    <!-- Mostrar mensajes de éxito -->
    <?php if ($resultado === '1'): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            Vendedor(a) añadido correctamente.
        </div>
    <?php elseif ($resultado === '2'): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            Vendedor(a) actualizado correctamente.
        </div>
    <?php elseif ($resultado === '3'): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            Vendedor(a) eliminado correctamente.
        </div>
    <?php endif; ?>

    <a href="index2.php" class="boton boton-verde">Volver</a>
    <a href="crear_vendedor.php" class="boton boton-amarillo">Añadir Vendedor</a>

    <!-- Tabla de vendedores -->
    <table class="vendedores">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($vendedor = mysqli_fetch_assoc($resultadoConsulta)): ?>
                <tr>
                    <td><?php echo $vendedor['id']; ?></td>
                    <td><?php echo htmlspecialchars($vendedor['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($vendedor['apellido']); ?></td>
                    <td><?php echo htmlspecialchars($vendedor['telefono']); ?></td>
                    <td class="acciones">
                        <!-- Formulario para eliminar -->
                        <form method="POST" onsubmit="return confirmarEliminacion();">
                            <input type="hidden" name="id" value="<?php echo $vendedor['id']; ?>">
                            <input type="submit" class="btn btn-eliminar" value="Eliminar">
                        </form>
                        <!-- Botón para actualizar -->
                        <a href="actualizar-vendedor.php?id=<?php echo $vendedor['id']; ?>" class="btn btn-actualizar">Actualizar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</main>

<?php
// Cerrar la conexión a la base de datos
mysqli_close($db);

// Incluir la plantilla del pie de página
incluirTemplate('footer');
?>

<!-- JavaScript para confirmar eliminación -->
<script>
    function confirmarEliminacion() {
        return confirm('¿Estás seguro de que deseas eliminar este vendedor?');
    }
</script>

<!-- Estilos CSS -->
<style>
    .alerta.exito {
        color: white;
        background-color: #71B100;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        font-weight: bold;
        text-align: center;
        position: relative;
    }

    .alerta.exito .cerrar {
        position: absolute;
        top: 5px;
        right: 10px;
        background-color: transparent;
        border: none;
        color: white;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
    }

    .vendedores {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .vendedores th {
        background-color: #71B100;
        color: white;
        text-align: left;
        padding: 10px;
    }

    .vendedores td {
        padding: 10px;
        background-color: white;
    }

    .acciones {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        border-radius: 5px;
        cursor: pointer;
        text-align: center;
        width: 100%; 
        transition: background-color 0.3s ease;
    }

    .btn-eliminar {
        background-color: red;
        color: white;
    }

    .btn-eliminar:hover {
        background-color: darkred;
    }

    .btn-actualizar {
        background-color: orange;
        color: white;
    }

    .btn-actualizar:hover {
        background-color: darkorange;
    }
</style>
