<?php 
    include './includes/templates/header.php';
?>

    <main class="contenedor seccion">
        <h1>Titulo Página</h1>
    </main>

    <?php 
    
    include './includes/templates/footer.php';
?>