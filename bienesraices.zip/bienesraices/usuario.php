<?php

// Importar la conexión
require 'includes/config/database.php';
$db = conectarDB();

// Crear un email y password
$email = "correo@correo.com";
$password = 123456;

// Hashear la contraseña
$passwordHash = password_hash($password, PASSWORD_BCRYPT);

// Query para crear el usuario
$query = "INSERT INTO usuarios (email, password) VALUES ('${email}', '${passwordHash}')";

// Agregarlo a la base de datos y verificar si ocurre algún error
$result = mysqli_query($db, $query);

if ($result) {
    echo "Usuario creado correctamente.";
} else {
    echo "Error al crear el usuario: " . mysqli_error($db);
}
