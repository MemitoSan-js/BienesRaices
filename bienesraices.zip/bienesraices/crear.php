<?php
session_start();



$auth = $_SESSION['login'];

if(!$auth){
    header('Location: index.php ');
}

// Base de datos
require 'includes/config/database.php';
$db = conectarDB();

// Consulta para obtener a los vendedores
$consulta = "SELECT * FROM vendedores";
$resultado = mysqli_query($db, $consulta);

// Arreglo con mensajes de errores
$errores = [];

$titulo = '';
$precio = '';
$descripccion = '';
$habitaciones = '';
$wc = '';
$estacionamiento = '';
$vendedor_id = '';

// Ejecutar código después de que el usuario envía el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $titulo = mysqli_real_escape_string($db, $_POST['titulo']);
    $precio = str_replace(',', '', mysqli_real_escape_string($db, $_POST['precio'])); // Eliminar comas
    $descripccion = mysqli_real_escape_string($db, $_POST['descripccion']);
    $habitaciones = mysqli_real_escape_string($db, $_POST['habitaciones']);
    $wc = mysqli_real_escape_string($db, $_POST['wc']);
    $estacionamiento = mysqli_real_escape_string($db, $_POST['estacionamiento']);
    $creado = date('Y/m/d');
    $vendedor_id = mysqli_real_escape_string($db, $_POST['vendedor']);

    // Asignar files hacia una variable
    $imagen = $_FILES['imagen'];

    if (!$titulo) {
        $errores[] = 'El título es obligatorio';
    }
    if (!$precio || !preg_match('/^\d{1,12}(\.\d{1,2})?$/', $precio)) {
        $errores[] = 'El precio es obligatorio y debe ser numérico con hasta 12 dígitos y 2 decimales.';
    }
    if (strlen($descripccion) >= 300) {
        $errores[] = 'La descripción es obligatoria y no debe tener más de 300 caracteres';
    }
    if (!$habitaciones) {
        $errores[] = 'El número de habitaciones es obligatorio';
    }
    if (!$wc) {
        $errores[] = 'El número de baños es obligatorio';
    }
    if (!$estacionamiento) {
        $errores[] = 'El número de estacionamientos es obligatorio';
    }
    if (!$vendedor_id) {
        $errores[] = 'Elige un vendedor';
    }
    if (!$imagen['name'] || $imagen['error']) {
        $errores[] = 'La imagen es obligatoria';
    }

    // Validar imagen por tamaño
    $medida = 10000 * 1000; // 1 MB
    if ($imagen['size'] > $medida) {
        $errores[] = 'La imagen es muy pesada';
    }

    // Revisar que el arreglo de errores esté vacío
    if (empty($errores)) {
        // Subida de archivos
        $carpetaImagenes = 'imagenes/';
        if (!is_dir($carpetaImagenes)) {
            mkdir($carpetaImagenes);
        }

        // Generar un nombre único
        $nombreImagen = md5(uniqid(rand(), true)) . ".jpg";

        // Subir la imagen
        move_uploaded_file($imagen['tmp_name'], $carpetaImagenes . $nombreImagen);

        // Insertar en la base de datos
        $query = "INSERT INTO propiedades (titulo, precio, imagen, descripccion, habitaciones, wc, estacionamiento, creado, vendedor_id) 
        VALUES ('$titulo', '$precio', '$nombreImagen', '$descripccion', '$habitaciones', '$wc', '$estacionamiento', '$creado', '$vendedor_id')";

        $resultado = mysqli_query($db, $query);

        if ($resultado) {
            // Redireccionar al usuario
            header('Location: index2.php?resultado=1');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienes Raíces</title>
    <style>
        .alerta.error {
            color: red;
            font-weight: bold;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid red;
            background-color: #ffe5e5;
            border-radius: 5px;
        }
        #contador-descripcion, #contador-precio, #contador-titulo {
            font-size: 0.9em;
            color: #555;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <?php
    require 'includes/funciones.php';
    incluirTemplate('header');
    ?>

    <main class="contenedor seccion">
        <h1>Crear</h1>

        <a href="index2.php" class="boton boton-verde">Volver</a>

        <?php foreach ($errores as $error): ?>
            <div class="alerta error">
                <?php echo $error; ?>
            </div>
        <?php endforeach; ?>

        <form class="formulario" method="POST" action="crear.php" enctype="multipart/form-data">
            <fieldset>
                <legend>Información General</legend>

                <label for="titulo">Título:</label>
                <input type="text" id="titulo" name="titulo" placeholder="Título propiedad" value="<?php echo $titulo; ?>" maxlength="100">
                <p id="contador-titulo">0/100 caracteres</p>

                <label for="precio">Precio:</label>
                <input type="text" id="precio" name="precio" placeholder="Precio propiedad" value="<?php echo $precio; ?>" maxlength="12" pattern="^\d{1,12}(\.\d{1,2})?$" title="Solo se permiten números con hasta 2 decimales, máximo 12 dígitos en total">
                <p id="contador-precio">0/12</p>

                <label for="imagen">Imagen:</label>
                <input type="file" id="imagen" accept="image/jpeg, image/png" name="imagen">

                <label for="descripccion">Descripción:</label>
                <textarea id="descripccion" placeholder="Ej: Describa la propiedad" name="descripccion" maxlength="300"><?php echo $descripccion; ?></textarea>
                <p id="contador-descripcion">0/300 caracteres</p>
            </fieldset>

            <fieldset>
                <legend>Información de la propiedad</legend>
                <label for="habitaciones">Habitaciones:</label>
                <input type="number" id="habitaciones"  placeholder="Ej: 3" name="habitaciones" min="1" max="9" value="<?php echo $habitaciones; ?>">

                <label for="wc">Baños:</label>
                <input type="number" id="wc" placeholder="Ej: 1.5"  name="wc" min="1" max="9" step="0.1" value="<?php echo $wc; ?>">

                <label for="estacionamiento">Estacionamiento:</label>
                <input type="number" id="estacionamiento" placeholder="Ej: 3" name="estacionamiento" min="1" max="9" value="<?php echo $estacionamiento; ?>">
            </fieldset>

            <fieldset>
                <legend>Vendedor</legend>
                <select name="vendedor">
                    <option value="">--Seleccione--</option>
                    <?php while ($vendedor = mysqli_fetch_assoc($resultado)): ?>
                        <option <?php echo $vendedor_id === $vendedor['id'] ? 'selected' : ''; ?> value="<?php echo $vendedor['id']; ?>">
                            <?php echo $vendedor['nombre'] . " " . $vendedor['apellido']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </fieldset>

            <input type="submit" value="Crear Propiedad" class="boton boton-verde">
        </form>
    </main>

    <?php incluirTemplate('footer'); ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const inputTitulo = document.getElementById('titulo');
            const contadorTitulo = document.getElementById('contador-titulo');
            const descripcion = document.getElementById('descripccion');
            const contadorDescripcion = document.getElementById('contador-descripcion');
            const inputPrecio = document.getElementById('precio');
            const contadorPrecio = document.getElementById('contador-precio');

            // Contador para el precio
            inputPrecio.addEventListener('input', () => {
                const caracteresEscritos = inputPrecio.value.length;
                contadorPrecio.textContent = `${caracteresEscritos}/12 caracteres`;
            });

            // Limitar los caracteres para el título
            inputTitulo.addEventListener('input', () => {
                const contador = inputTitulo.value.length;
                contadorTitulo.textContent = `${contador}/100`;
            });

            // Limitar los caracteres para la descripción
            descripcion.addEventListener('input', () => {
                const contador = descripcion.value.length;
                contadorDescripcion.textContent = `${contador}/300`;
            });
        });
    </script>
</body>
</html>
