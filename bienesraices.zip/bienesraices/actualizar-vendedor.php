<?php
// Validar si el usuario está autenticado
require 'includes/funciones.php';
incluirTemplate('header');

session_start();
$auth = $_SESSION['login'] ?? false;

if (!$auth) {
    header('Location: index.php');
    exit;
}

// Conectar a la base de datos
require 'includes/config/database.php';
$db = conectarDB();

// Validar ID del vendedor
$id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

if (!$id) {
    header('Location: vendedor.php');
    exit;
}

// Obtener datos del vendedor actual
$query = "SELECT * FROM vendedores WHERE id = $id";
$resultado = mysqli_query($db, $query);
$vendedor = mysqli_fetch_assoc($resultado);

// Si el vendedor no existe, redirigir
if (!$vendedor) {
    header('Location: vendedor.php');
    exit;
}

// Inicializar variables con los valores existentes
$nombre = $vendedor['nombre'];
$apellido = $vendedor['apellido'];
$telefono = $vendedor['telefono'];

// Arreglo para almacenar errores
$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitizar y asignar valores
    $nombre = mysqli_real_escape_string($db, $_POST['nombre']);
    $apellido = mysqli_real_escape_string($db, $_POST['apellido']);
    $telefono = mysqli_real_escape_string($db, $_POST['telefono']);

    // Validar los campos
    if (!$nombre) {
        $errores[] = 'El Nombre es obligatorio';
    }
    if (!$apellido) {
        $errores[] = 'El Apellido es obligatorio';
    }
    if (!$telefono) {
        $errores[] = 'El Teléfono es obligatorio';
    }

    // Si no hay errores, actualizar en la base de datos
    if (empty($errores)) {
        $query = "UPDATE vendedores SET 
                  nombre = '$nombre', 
                  apellido = '$apellido', 
                  telefono = '$telefono' 
                  WHERE id = $id";
        
        $resultado = mysqli_query($db, $query);

        if ($resultado) {
            // Redireccionar al usuario
            header('Location: vendedor.php?resultado=2');
            exit;
        }
    }
}
?>

<main class="contenedor seccion">
    <h1>Actualizar Vendedor</h1>
    <a href="vendedor.php" class="boton boton-verde">Volver</a>

    <!-- Mostrar errores -->
    <?php foreach ($errores as $error): ?>
        <div class="alerta error">
            <?php echo $error; ?>
        </div>
    <?php endforeach; ?>

    <!-- Formulario -->
    <form method="POST" class="formulario">
        <fieldset>
            <legend>Información del Vendedor</legend>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Nombre del vendedor" value="<?php echo htmlspecialchars($nombre); ?>">

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" placeholder="Apellido del vendedor" value="<?php echo htmlspecialchars($apellido); ?>">

            <label for="telefono">Teléfono:</label>
            <input type="tel" id="telefono" name="telefono" placeholder="Teléfono del vendedor" value="<?php echo htmlspecialchars($telefono); ?>">
        </fieldset>

        <input type="submit" value="Actualizar Vendedor" class="boton boton-verde">
    </form>
</main>

<?php
//cerrar la conexion
mysqli_close($db);
incluirTemplate('footer');
?>
