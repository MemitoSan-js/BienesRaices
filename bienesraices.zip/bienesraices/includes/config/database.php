<?php

function conectarDB() :mysqli {
    $db = mysqli_connect('localhost','root','9515125473','bienesraices_crud');
    
    if(!$db){
        echo "Error no se pudo conectar la base de datos";
        exit;
    }
    return $db;
}