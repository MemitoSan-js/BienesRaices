<?php
// Validar si el usuario está autenticado
require 'includes/funciones.php';
incluirTemplate('header');

session_start();
$auth = $_SESSION['login'] ?? false;

if (!$auth) {
    header('Location: index.php');
    exit;
}

// Conectar a la base de datos
require 'includes/config/database.php';
$db = conectarDB();

// Arreglo para almacenar errores
$errores = [];

$nombre = '';
$apellido = '';
$telefono = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitizar y asignar valores
    $nombre = mysqli_real_escape_string($db, $_POST['nombre']);
    $apellido = mysqli_real_escape_string($db, $_POST['apellido']);
    $telefono = mysqli_real_escape_string($db, $_POST['telefono']);

    // Validar los campos
    if (!$nombre || strlen($nombre) > 40) {
        $errores[] = 'El Nombre es obligatorio y no debe exceder 40 caracteres';
    }
    if (!$apellido || strlen($apellido) > 40) {
        $errores[] = 'El Apellido es obligatorio y no debe exceder 40 caracteres';
    }
    if (!$telefono || strlen($telefono) !== 10) {
        $errores[] = 'El Teléfono es obligatorio y debe tener exactamente 10 dígitos';
    }

    // Si no hay errores, insertar en la base de datos
    if (empty($errores)) {
        $query = "INSERT INTO vendedores (nombre, apellido, telefono) 
                  VALUES ('$nombre', '$apellido', '$telefono')";
        
        $resultado = mysqli_query($db, $query);

        if ($resultado) {
            // Redireccionar al usuario
            header('Location: vendedor.php?resultado=1');
            exit;
        }
    }
}
?>

<main class="contenedor seccion">
    <h1>Crear Vendedor(a)</h1>
    <a href="vendedor.php" class="boton boton-verde">Volver</a>

    <!-- Mostrar errores -->
    <?php foreach ($errores as $error): ?>
        <div class="alerta error">
            <?php echo $error; ?>
        </div>
    <?php endforeach; ?>

    <!-- Formulario -->
    <form method="POST" class="formulario">
        <fieldset>
            <legend>Información del Vendedor</legend>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" placeholder="Nombre del vendedor" maxlength="40" value="<?php echo htmlspecialchars($nombre); ?>">
            <p id="nombre-counter">0/40 caracteres</p>

            <label for="apellido">Apellido:</label>
            <input type="text" id="apellido" name="apellido" placeholder="Apellido del vendedor" maxlength="40" value="<?php echo htmlspecialchars($apellido); ?>">
            <p id="apellido-counter">0/40 caracteres</p>

            <label for="telefono">Teléfono:</label>
            <input type="tel" id="telefono" name="telefono" placeholder="Teléfono del vendedor" maxlength="10" value="<?php echo htmlspecialchars($telefono); ?>">
            <p id="telefono-counter">0/10 caracteres</p>
        </fieldset>

        <input type="submit" value="Crear Vendedor" class="boton boton-verde">
    </form>
</main>

<script>
// Actualizar contadores en tiempo real
function updateCounter(inputId, counterId, maxLength) {
    const input = document.getElementById(inputId);
    const counter = document.getElementById(counterId);

    input.addEventListener('input', () => {
        const currentLength = input.value.length;
        counter.textContent = `${currentLength}/${maxLength} caracteres`;
    });
}

// Configurar contadores
updateCounter('nombre', 'nombre-counter', 40);
updateCounter('apellido', 'apellido-counter', 40);
updateCounter('telefono', 'telefono-counter', 10);
</script>

<?php
incluirTemplate('footer');
?>
