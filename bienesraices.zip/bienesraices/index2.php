<?php
session_start();

$auth = $_SESSION['login'];

if (!$auth) {
    header('Location: index.php');
}

//importar la conexion
require 'includes/config/database.php';
$db = conectarDB();

//escribir el Query
$query = "SELECT * FROM propiedades";

//Consultar la base de datos
$resultadoConsulta = mysqli_query($db, $query);

//muestra de mensaje condicional
$resultado = $_GET['resultado'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if ($id) {
        //eliminar el archivo
        $query = "SELECT imagen FROM propiedades WHERE id = ${id}";
        $resultado = mysqli_query($db, $query);
        $propiedad = mysqli_fetch_assoc($resultado);
        unlink('imagenes/' . $propiedad['imagen']);

        //eliminar la propiedad
        $query = "DELETE FROM propiedades WHERE id = ${id}";
        $resultado = mysqli_query($db, $query);
        if ($resultado) {
            header('Location: index2.php?resultado=3');
        }
    }
}

require 'includes/funciones.php';
incluirTemplate('header');
?>

<main class="contenedor seccion">
    <h1>Administrador de Bienes Raices</h1>

    <?php if (intval($resultado) === 1): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            PROPIEDAD CREADA CORRECTAMENTE
        </div>
    <?php elseif (intval($resultado) === 2): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            PROPIEDAD ACTUALIZADA CORRECTAMENTE
        </div>
    <?php elseif (intval($resultado) === 3): ?>
        <div class="alerta exito">
            <button class="cerrar" onclick="this.parentElement.style.display='none';">&times;</button>
            PROPIEDAD ELIMINADA CORRECTAMENTE
        </div>
    <?php endif; ?>

    <a href="crear.php" class="boton boton-verde crear-propiedad">Crear Propiedad</a>
    <a href="vendedor.php" class="boton boton-amarillo añadir'vendedor">Añadir Vendedor(a)</a>

    <table class="propiedades">
        <thead>
            <tr>
                <th>ID</th>
                <th>Titulo</th>
                <th>Imagen</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($propiedad = mysqli_fetch_assoc($resultadoConsulta)): ?>
                <tr>
                    <td><?php echo $propiedad['id']; ?></td>
                    <td><?php echo $propiedad['titulo']; ?></td>
                    <td><img src="imagenes/<?php echo $propiedad['imagen']; ?>" class="imagen-tabla" alt="Imagen de la propiedad"></td>
                    <td>$ <?php echo $propiedad['precio']; ?></td>
                    <td class="acciones">
                        <form method="POST" onsubmit="return confirmarEliminacion();">
                            <input type="hidden" name="id" value="<?php echo $propiedad['id']; ?>">
                            <input type="submit" class="btn btn-eliminar" value="Eliminar">
                        </form>
                        
                        <a href="actualizar.php?id=<?php echo $propiedad['id']; ?>" class="btn btn-actualizar">Actualizar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</main>

<!-- Bloque de estilos CSS -->
<style>
    .alerta.exito {
        color: white;
        background-color: #71B100;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
        font-weight: bold;
        text-align: center;
        position: relative;
    }

    .alerta.exito .cerrar {
        position: absolute;
        top: 5px;
        right: 10px;
        background-color: transparent;
        border: none;
        color: white;
        font-size: 18px;
        font-weight: bold;
        cursor: pointer;
    }

    .propiedades {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .propiedades th {
        background-color: #71B100;
        color: white;
        text-align: left;
        padding: 10px;
    }

    .propiedades td {
        color: black;
        background-color: white;
        padding: 10px;
    }

    .propiedades img.imagen-tabla {
        width: 10rem;
        height: auto;
    }

    .crear-propiedad {
        margin-bottom: 20px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        border-radius: 5px;
        cursor: pointer;
        width: 100%; 
        transition: background-color 0.3s ease;
    }

    .btn-eliminar {
        background-color: red;
        color: white;
    }

    .btn-eliminar:hover {
        background-color: darkred;
    }

    .btn-actualizar {
        background-color: orange;
        color: white;
    }

    .btn-actualizar:hover {
        background-color: darkorange;
    }

    .acciones {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
</style>

<script>
    function confirmarEliminacion() {
        return confirm('¿Está seguro de que desea eliminar esta propiedad? Esta acción no se puede deshacer.');
    }
</script>

<?php
//cerrar la conexion
mysqli_close($db);

incluirTemplate('footer');
?>
